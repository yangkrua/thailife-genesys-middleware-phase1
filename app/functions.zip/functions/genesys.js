const Client                = require('ssh2-sftp-client');
const sftp                  = new Client();
const log                   = require("../functions/logger.js").LOG;
const fs                    = require('node:fs');

const path                  = require('path');
const moment                = require('moment');

const config                = require('../config/server.js'); 
const platformClient        = require('purecloud-platform-client-v2');
const apiInstance           = new platformClient.ConversationsApi();
const usersApi              = new platformClient.UsersApi();
//const routingApi            = new platformClient.RoutingApi();

const client                = platformClient.ApiClient.instance;
const CLIENT_ID             = config.GENESES.client_id;
const CLIENT_SECRET         = config.GENESES.client_secret;  
client.setEnvironment(config.GENESES.org_region);

/*
 * getUserLists
 */
let getUserLists = async () => {
  let usersObj;
  
  await usersApi.getUsers({ 
      "pageSize": 100,
      "pageNumber": 1,		  		  
      "sortOrder": "asc",		  		  
      "state": "active"
    }).then(async (data) => {

      log.info(`usersApi.getUsers(), Page=1, Result= ${JSON.stringify(data)}`);

      usersObj = await data;
      for(let j=2; j <= data.pageCount; j++){
          let dataResult = await usersApi.getUsers(
              { 
              "pageSize": 100,
              "pageNumber": j,		  		  
              "sortOrder": "asc",		  		  
              "state": "active"
            });

            log.info(`usersApi.getUsers(), Page=${j}, Result= ${JSON.stringify(data)}`);
            Array.prototype.push.apply(usersObj.entities, dataResult.entities);
      }
    });    

  return usersObj;
};


/*
* AnalyticsConversationsDetailsQuery
*/
let AnalyticsConversationsDetailsQuery = () => {
  client.loginClientCredentialsGrant(CLIENT_ID, CLIENT_SECRET)
  .then(()=> {
    log.info('AnalyticsConversationsDetailsQuery->login(), success fully!');     
      //let body = {"interval": "2024-02-01T00:00:00.000Z/2024-02-07T00:00:00.000Z"}; // Object | query
      //dev
      //const pDateStart =  moment('2024-02-01T00:00:00.000').add(-config.GENESES.data_query_period, 'minute');
      //const pDateStop  =  moment('2024-02-07T00:00:00.000');

      //pro
      const pDateStart =  moment().add(-config.GENESES.data_query_period, 'minute');
      const pDateStop  =  moment();

      let body =
          {
              "interval": pDateStart.format('YYYY-MM-DDTHH:mm:ss.SSSZ')+"/"+pDateStop.format('YYYY-MM-DDTHH:mm:ss.SSSZ'),
              "segmentFilters": [
                {
                  "predicates": [
                    {
                      "dimension": "purpose",
                      "value": "Customer"
                    },
                    {
                      "dimension": "direction",
                      "value": "inbound"
                    }
                  ],
                  "type": "and"
                }
              ]
            };
      // Query for conversation details
      apiInstance.postAnalyticsConversationsDetailsQuery(body)
      .then(async (data) => {
        log.info('AnalyticsConversationsDetailsQuery->Query(), success fully!');     
        //log.info(`API->postAnalyticsConversationsDetailsQuery(), success fully!, Data: ${JSON.stringify(data)}`);
        if(data.totalHits > 0){  
          log.info(`AnalyticsConversationsDetailsQuery->Query(), Total-Record=${data.totalHits}`);    
          let lineCDR   = await parserCDR(data);     
          const localPath = `${config.GENESES.data_process_inbox}/L_ABANDON_CALL_${moment().format('YYYYMMDD_HHmmss')}.txt`;
          await writeFile(localPath,lineCDR);
          ftpFileCDR(localPath);
        }else{
          log.info('AnalyticsConversationsDetailsQuery->Query(), No More Records!');  
        }        
      })
      .catch((error) => {
        log.error(`API->postAnalyticsConversationsDetailsQuery(), error: ${error.message}`);   
      });
  })
  .catch((error) => {
      log.error(`API->loginClientCredentialsGrant(), error: ${error.message}`); 
  });
};

/*
* GetLoginLogoutDailyReport
*/
let GetLoginLogoutDailyReport = () => {
  client.loginClientCredentialsGrant(CLIENT_ID, CLIENT_SECRET)
  .then(async () => {
    log.info('GetUsers->login(), success fully!');      
    let users = await getUserLists();
    log.info(`API->GetUsers, Result: ${JSON.stringify(users)}`); 
    const pDate =  moment().add(-1, 'days');
    const timePeriod = pDate.format('YYYY-MM-DDT00:00:00.000Z')+"/"+pDate.format('YYYY-MM-DDT23:59:59.000Z');
    
    let body =
    {
      "interval": timePeriod,
      "presenceFilters": [
          {
            "type": "or",
            "predicates": [
                {
                   "dimension": "systemPresence",
                   "value": "AVAILABLE"
                },
                {
                  "dimension": "systemPresence",
                  "value": "OFFLINE"
                }
            ]
          }          
      ],      
      "presenceAggregations": [
          {
              "type": "termFrequency",
              "dimension": "organizationPresenceId",
              "size": 50
          }
      ],
      "paging": {
        "pageSize": 100,
        "pageNumber": 1
      },
      "order": "asc"
    };

    log.info(`usersApi.postAnalyticsUsersDetailsQuery->Body= ${JSON.stringify(body)}`);
    let textDataHeader = 'ID|USERNAME|EMAIL|START_TIME|STOP_TIME|DURATION';
    let textDataBody   = '';    
    let pageTotal      = 2;
    let dataResult;
            
    dataResult = await usersApi.postAnalyticsUsersDetailsQuery(body);
    log.info(`API->postAnalyticsUsersDetailsQuery, PageNo=1, Result: ${JSON.stringify(dataResult)}`); 

    if(dataResult !== undefined && dataResult.totalHits > 0){
      pageTotal = Math.round(dataResult.totalHits/100);

      //first Page
      textDataBody = await parserUsersLoginAvailable(dataResult, users);

      //seconds Page
      for(let i=1; i< pageTotal; i++){
        body.paging.pageNumber = i+1;      
        dataResult = await usersApi.postAnalyticsUsersDetailsQuery(body);
        log.info(`API->postAnalyticsUsersDetailsQuery, PageNo=${body.paging.pageNumber}, Result: ${JSON.stringify(dataResult)}`); 
        
        textDataBody += await '\n';
        textDataBody += await parserUsersLoginAvailable(dataResult, users);
      }//end for
    }

    //ftp file
    if(textDataBody!== ''){
      const localPath = `${config.GENESES.data_process_inbox}/LOGIN_LOGOUT_DAILY_${moment().format('YYYYMMDD_HHmmss')}.txt`;
      await writeFile(localPath,`${textDataHeader}\n${textDataBody}`);
      await ftpFileCDR(localPath);
    }
  })
  .catch((error) => {
    log.error(`API->GetUsers(), error: ${error.message}`); 
  })
};

let writeFile= (path, text) =>{
  log.info(`====== writeFile, path=${path}`);
  return fs.appendFile(path, `${text}\n`, function (err) {
    if (err) {
      log.error(`API->writeFile(), error: ${err.message}`); 
      return;
    } 
    log.info("API->writeFile(), Done!");
  })
};

let moveFile = async (srcFile) =>{
  const destFile = `${config.SFTP.local_outbox_path}/${moment().format('YYYYMMDD')}/${path.basename(srcFile)}`;
  if(!fs.existsSync(path.dirname(destFile))){
    fs.mkdirSync(path.dirname(destFile));
  }
  fs.rename(srcFile, destFile, function (err) {
    if (err) {
      log.error(`API->moveFile(), error: ${err.message}`); 
      return;
    } 
    log.error(`API->moveFile(), Success Fully!`); 
  })
}

let getUserName = (users, user_id) => {
  for(const user of users.entities) {
    if(user.id === user_id){
      return user.name + '|' + user.email;
    }
  }
  return '|';
}

let getUserLoginTime = async (primaryPresence) => {
  let st, et;  

  for(const item of primaryPresence){    
    if(item.systemPresence === 'OFFLINE' && st ===undefined){
      continue;
    }

    //--next item
    if(item.systemPresence === 'AVAILABLE' && st ===undefined){
      st = await moment(item.startTime);
      et = await moment(item.startTime);
      continue;
    }

    if(item.systemPresence === 'OFFLINE'){
      et = await moment(item.startTime);
    }
  }//end for

  if(st ===undefined || et ===undefined){
    st = await moment(primaryPresence[0].startTime);
    et = await moment(primaryPresence[0].startTime);
  }

  const duration   =moment.duration(et.diff(st)); 
  const ss         =duration.seconds();
  const mm         =duration.minutes();
  const hh         =duration.hours();

  return {
    startTime: `${st.format('YYYY-MM-DD HH:mm:ss')}`,
    endTime: `${et.format('YYYY-MM-DD HH:mm:ss')}`,
    ttl: `${hh.toFixed(0).padStart(2,'0')}:${mm.toFixed(0).padStart(2,'0')}:${ss.toFixed(0).padStart(2,'0')}`    
  }

};

let parserUsersLoginAvailable = async (data, users) => {
  log.info(`====== parserUsersLoginAvailable->Begin =======`);   
   
  let textUsers = '';
  try{
    for(const item of data.userDetails){    
      let userInfo = await getUserLoginTime(item.primaryPresence);
      if(textUsers !== ''){
        textUsers += '\n';
      }
      
      textUsers +=  item.userId + '|';                         //ID
      textUsers +=  getUserName(users, item.userId) + '|';     //USERNAME|EMAIL
      textUsers +=  userInfo.startTime  + '|';                 //START_TIME
      textUsers +=  userInfo.endTime  + '|';                   //STOP_TIME
      textUsers +=  userInfo.ttl;                              //DURATION_TIME
    }
  }catch(error){
    log.error(`API->parserUsersLoginAvailable(), error: ${error.message}`); 
  }
  
  return textUsers;
}

let parserPhoneNumber = (mobile) => {
  return mobile.replace("+66", "0");
}

let parserCDR = (data) => {
  log.info(`====== parserCDR->Begin =======`);   
    let textCRD = 'CALLING_PTY|STATUS|IMPORT_DATE|CHG_TIME|CALLID|SEGSTART|SEGSTOP|DISPOSITION|DISPVDN|UCID|ROUND_NO';
    for(const item of data.conversations){
        textCRD += '\n';
        textCRD += parserPhoneNumber(item.participants[0].sessions[0].ani.split(':')[1]) + '|';    //CALLING_PTY
        textCRD += "P" + '|';                                                                      //STATUS
        textCRD += moment().format('YYYY-MM-DD HH:mm:ss') + '|';                                   //IMPORT_DATE
        textCRD += moment().format('YYYY-MM-DD HH:mm:ss') + '|';                                   //CHG_TIME
        textCRD += item.conversationId  + '|';                                                     //CALLID
        textCRD += moment(item.conversationStart).format('YYYY-MM-DD HH:mm:ss') + '|';             //SEGSTART 
        textCRD += moment(item.conversationEnd).format('YYYY-MM-DD HH:mm:ss') + '|';               //SEGSTOP
        textCRD += "3|";                                                                           //DISPOSITION             
        textCRD +=  parserPhoneNumber(item.participants[0].sessions[0].dnis.split(':')[1]) + '|';  //DISPVDN
        textCRD += item.conversationId + '|';                                                      //UCID
        textCRD += 999;                                                                            //ROUND_NO                 
    };
    
    log.info(`====== parserCDR->Done! =======`);
    return textCRD;
};

let ftpFileCDR = (localPath) => {
  log.info("ftpFileCDR(), Begin... Uploading...");
  sftp.connect({
    host: config.SFTP.host,
    port: config.SFTP.port,
    username: config.SFTP.username,
    password: config.SFTP.password
  }).then(() => {
    return sftp.put(localPath, `${config.SFTP.remote_path}/${path.basename(localPath)}`);
  }).then((data) => {
    log.error(`API->ftpFileCDR(), success fully: ${data}`); 
    sftp.end();
    moveFile(localPath);
  }).catch((err) => {
    log.error(`API->ftpFileCDR(), error: ${err.message}`); 
  });
}

module.exports = {
  getUserLists,
  ftpFileCDR,
  parserCDR,
  writeFile,
  moveFile,
  getUserName,
  parserPhoneNumber,
  getUserLoginTime,
  parserUsersLoginAvailable,
  GetLoginLogoutDailyReport,
  AnalyticsConversationsDetailsQuery
};
